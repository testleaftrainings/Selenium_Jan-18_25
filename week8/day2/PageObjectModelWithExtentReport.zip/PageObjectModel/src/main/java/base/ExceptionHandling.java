package base;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExceptionHandling {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		try {
			driver.findElement(By.id("username")).sendKeys("Demo");
			throw new NoSuchElementException("Check the locator value");
		} catch (Exception e) {
			System.out.println(e);
			driver.findElement(By.id("username")).sendKeys("Demosalesmanager");

		}finally {
			System.out.println("UserName entered");
		}
		
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	
		//compile time exception
		//throw and throws
		
		//throw - its user defined exception
		//throws - its system defined exception ->  pre defined one 
		
		Thread.sleep(3000);
		
		
	}
}
