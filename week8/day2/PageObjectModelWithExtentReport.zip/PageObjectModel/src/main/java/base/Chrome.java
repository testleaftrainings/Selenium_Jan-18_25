package base;

public class Chrome {
	/*
	 * boolean status;
	 * 
	 * 
	 * //default constructor public Chrome() {
	 * System.out.println("I am default constructor"); }
	 * 
	 * //parameterized public Chrome(boolean status) { this();
	 * 
	 * this.status=status;
	 * 
	 * System.out.println(this.status);
	 * 
	 * 
	 * }
	 * 
	 * 
	 * public Chrome(String n, int a) {
	 * 
	 * this(true); }
	 * 
	 * 
	 * 
	 * public static void main(String[] args) { Chrome c=new Chrome();
	 * 
	 * Chrome c1=new Chrome(true);
	 * 
	 * 
	 * System.out.println("default value :"+c.status); }
	 */
	
	
	
	
	
	public static void main(String[] args) {
		
		int random = (int)(Math.random()*99999);
		System.out.println(random);
	}
	
	//0.4567895
	//46529.78900
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
