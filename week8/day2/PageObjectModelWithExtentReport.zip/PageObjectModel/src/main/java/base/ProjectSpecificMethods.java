package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();
 public static ExtentReports extents;
public static ExtentTest test;
public String testName,testDescription,testAuthor,testCategory;

 
	//set the driver
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}

	//get the driver value
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}


	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));	
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter wb=new ExtentHtmlReporter("./report/loginreport.html");
		wb.setAppendExisting(true);		
	   extents=new ExtentReports();
		extents.attachReporter(wb);
	}

	@AfterSuite
	public void stopReport() {
		extents.flush();
	}

	@BeforeClass
	public void testDetails() {
		 test=extents.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	public void reportStep(String stepDetails, String status) throws IOException {
		if(status.equalsIgnoreCase("pass")) {
		test.pass(stepDetails, MediaEntityBuilder.createScreenCaptureFromPath(".././snapshot/snap"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			test.fail(stepDetails,MediaEntityBuilder.createScreenCaptureFromPath(".././snapshot/snap"+takeSnap()+".png").build());
		}
	}
	
	public int takeSnap() throws IOException {
		int random = (int)(Math.random()*99999);
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File dst=new File("./snapshot/snap"+random+".png");
		FileUtils.copyFile(src, dst);
		return random;
	}
	
	
	//snap45678
	//snap67890
	
	
}
