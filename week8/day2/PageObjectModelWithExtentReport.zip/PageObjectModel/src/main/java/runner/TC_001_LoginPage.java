package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_001_LoginPage extends ProjectSpecificMethods{

	@BeforeTest
	public void setValues() {
		testName="Login Page";
		testDescription="Check login page is working";
		testAuthor="Dilip";
		testCategory="Smoke";
	}
	
	
	
	
	@Test
	public void runLogin() throws IOException {
		
		LoginPage lp=new LoginPage();
		System.out.println(getDriver() +" LoginPage");
		lp.enterUserName("Demosalesmanager")
		.enterPassWord("crmsfa")
		.clickOnLogin()
		.clickOnCrmsfa();
		
	}
	
}
