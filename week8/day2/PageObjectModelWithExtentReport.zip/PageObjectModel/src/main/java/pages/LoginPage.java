package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage  extends ProjectSpecificMethods{
	
	
	
	@When("Enter the userName as {string}")
	public LoginPage enterUserName(String uName) throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(uName);
			reportStep("UserName entered successfully", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Username not entered ", "fail");
			
		}
		return this;
	}
	
	@And("Enter the passWord as {string}")
	public LoginPage enterPassWord(String passWd) throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(passWd);
			reportStep("Password entered successfully", "pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep("password is not entered", "fail");
		}
		return this;
	}
	
	
	@And("Click on Login Button")
	public HomePage clickOnLogin() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button clicked successfully", "pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep("Login is not clicked", "fail");
		}		
		return new HomePage();
		
	}
	

}
