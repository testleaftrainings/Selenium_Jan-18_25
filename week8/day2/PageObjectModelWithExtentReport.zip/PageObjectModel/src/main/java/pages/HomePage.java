package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods {	
	
	@Then("Verify Login is Successful")
	public void verifyLoginIsSuccessful() {
		String string = getDriver().getTitle();
		if(string.contains("Leaftaps")) {
			System.out.println("Login is Successful");
		}else {
			System.out.println("Login is not Successful");
		}
	}
	
	public MyHomePage clickOnCrmsfa() throws IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("Clicked on crmsfa", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("crmsfa is not clicked", "fail");
		}
		return new MyHomePage();
	}
	
	
	public LoginPage clickOnLogout() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Clicked on logout", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("logout is not clicked", "fail");

		}
		return new LoginPage();
	}

}
