package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests {

private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();


//set the driver
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}
	
	//get the driver value
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}

	
	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));	
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	
}
