package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReport {

	public static void main(String[] args) throws IOException {
		// step 1 
		ExtentHtmlReporter wb=new ExtentHtmlReporter("./report/loginreport.html");
wb.setAppendExisting(true);		
		//step 2
		ExtentReports extents=new ExtentReports();
		
		//step 3
		extents.attachReporter(wb);
		
		//step 4
		ExtentTest test=extents.createTest("loginpage", "check login page with positivevalue");
		test.assignAuthor("Dilip");
		test.assignCategory("sanity");
		
		//step5
		test.pass("enter the username is successful",MediaEntityBuilder.createScreenCaptureFromPath(".././snapshot/snap.png").build());
		test.pass("enter the password is sucessful");
		test.pass("Login button not clicked");
		
		//step 6
		extents.flush();
		
		System.out.println("done");
		
	}
}
