package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods {	
	
	@Then("Verify Login is Successful")
	public void verifyLoginIsSuccessful() {
		String string = getDriver().getTitle();
		if(string.contains("Leaftaps")) {
			System.out.println("Login is Successful");
		}else {
			System.out.println("Login is not Successful");
		}
	}
	
	public MyHomePage clickOnCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	
	
	public LoginPage clickOnLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

}
