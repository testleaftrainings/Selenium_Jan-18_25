package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage  extends ProjectSpecificMethods{
	
	
	
	@When("Enter the userName as {string}")
	public LoginPage enterUserName(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;
	}
	
	@And("Enter the passWord as {string}")
	public LoginPage enterPassWord(String passWd) {
		getDriver().findElement(By.id("password")).sendKeys(passWd);
		return this;
	}
	
	
	@And("Click on Login Button")
	public HomePage clickOnLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();		
		return new HomePage();
		
	}
	

}
