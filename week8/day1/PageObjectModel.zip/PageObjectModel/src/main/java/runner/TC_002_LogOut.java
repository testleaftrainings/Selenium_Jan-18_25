package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_002_LogOut extends ProjectSpecificMethods{

	
	@Test
	public void runLogin() {
		
		LoginPage lp=new LoginPage();
		System.out.println(getDriver() +" LogoutPage");
		lp.enterUserName("DemoSalesManager")
		.enterPassWord("crmsfa")
		.clickOnLogin()
		.clickOnLogout();
		
	}
	
}
