package runner;

import base.ProjectSpecificMethods;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="src/main/java/features/Login.feature",
glue="pages")

public class CucumberRunner extends ProjectSpecificMethods {

}
