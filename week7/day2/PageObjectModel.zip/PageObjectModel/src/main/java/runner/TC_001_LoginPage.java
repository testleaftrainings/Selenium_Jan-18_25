package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_001_LoginPage extends ProjectSpecificMethods{

	
	@Test
	public void runLogin() {
		
		LoginPage lp=new LoginPage(driver);
		System.out.println(driver +" LoginPage");
		lp.enterUserName("Demosalesmanager")
		.enterPassWord("crmsfa")
		.clickOnLogin()
		.clickOnCrmsfa();
		
	}
	
}
