package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_002_LogOut extends ProjectSpecificMethods{

	
	@Test
	public void runLogin() {
		
		LoginPage lp=new LoginPage(driver);
		System.out.println(driver +" LogoutPage");
		lp.enterUserName("DemoSalesManager")
		.enterPassWord("crmsfa")
		.clickOnLogin()
		.clickOnLogout();
		
	}
	
}
