package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage  extends ProjectSpecificMethods{
	
	//create own constructor call with paramter as driver
	public LoginPage(ChromeDriver driver) {
		
		this.driver=driver;
	}
	
	
	
	public LoginPage enterUserName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		
		return this;
	}
	
	
	public LoginPage enterPassWord(String passWd) {
		driver.findElement(By.id("password")).sendKeys(passWd);
		return this;
	}
	
	
	public HomePage clickOnLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		
		return new HomePage(driver);
		//wherever you have used nextpage constructor inside as driver variable
		
	}
	

}
